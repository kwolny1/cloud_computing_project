import json
import boto3
import os
import uuid
from datetime import datetime

# AWS Clients
comprehend = boto3.client('comprehend')
dynamodb = boto3.resource('dynamodb')
table_name = os.environ.get('DYNAMO_TABLE', 'StudyNotes')
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    try:
        # Get input text (could be from uploaded PDF or typed notes)
        body = json.loads(event.get('body', '{}'))
        user_text = body.get('text', '')

        if not user_text.strip():
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'No text provided.'})
            }

        # Use AWS Comprehend to detect key phrases (kind of like a summary)
        response = comprehend.detect_key_phrases(
            Text=user_text,
            LanguageCode='en'  # or 'pl' if you want Polish, but English is best-supported
        )

        key_phrases = [phrase['Text'] for phrase in response['KeyPhrases']]

        # Save original note + summary to DynamoDB
        item = {
            'note_id': str(uuid.uuid4()),
            'original_text': user_text,
            'key_phrases': key_phrases,
            'created_at': datetime.utcnow().isoformat()
        }

        table.put_item(Item=item)

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Note saved and summarized.',
                'key_phrases': key_phrases
            })
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Internal server error', 'details': str(e)})
        }
